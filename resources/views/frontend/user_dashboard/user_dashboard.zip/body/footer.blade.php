<section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright">
                    <p>Copyright © {{date('Y')}} Shubhvivah. All rights reserved.  by <a href="https://shubhvivah.us">Shubhvivah</a>.</p>
                </div>
            </div>
        </div>
    </div>
</section>