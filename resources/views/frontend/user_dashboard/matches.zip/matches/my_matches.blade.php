@extends('frontend.user_dashboard.body.layout')
@section('title')
My New Matches 
@stop
@section('description', 'Share text and photos with your friends and have fun')
@section('keywords', 'sharing, sharing text, text, sharing photo, photo,')
@section('robots', 'index, follow')
@section('revisit-after', 'content="3 days')
@section('content')
<!-- STATISTIC-->
<div class="row">

</div>

@endsection     

