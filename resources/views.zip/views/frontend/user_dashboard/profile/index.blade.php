@extends('frontend.user_dashboard.body.layout')
@section('title')
Edit Profile
@stop
@section('description', 'Share text and photos with your friends and have fun')
@section('keywords', 'sharing, sharing text, text, sharing photo, photo,')
@section('robots', 'index, follow')
@section('revisit-after', 'content="3 days')
@section('content')
@php
$all_user =  App\Models\User::get();
$get_user =  App\Models\User::orderBy('name')->latest()->get()->take(3);
$get_Country =  App\Models\Country::get();
$get_state = App\Models\State::get();
$get_heights = App\Models\Height::get();
$get_religion =  App\Models\Religion::get();
$get_diet = App\Models\Diet::get();
$profile_created = App\Models\ProfileCreated::get();
$marital_status = App\Models\MaritalStatus::get();





@endphp
<!-- STATISTIC-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<div class="row mt-5">

    <form action="{{route('update.auth.profile',$user_data->id)}}"  method="post" enctype="multipart/form-data">
        @csrf
    <div class="container rounded bg-white  mb-5">
        <div class="row">
  
            <div class="col-md-6 border-right">
                <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="text-right">Update Profile </h4>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-12"><label class="labels">Name</label>
                            <input type="text" name="name" class="form-control" value="{{$user_data->name}}">
                            @error('name')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                    
                        <div class="col-md-12"><label class="labels">Email</label>
                            <input type="text" name="email" class="form-control"  value="{{$user_data->email}}">
                            @error('email')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>

                        <div class="col-md-12"><label class="labels">Change Profile photo</label>
                            <input type="file" name="profile_photo_path" class="form-control"  accept="image/*" onchange="document.getElementById('output').src = window.URL.createObjectURL(this.files[0])">
                            @error('profile_photo_path')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>


                <!-- multiple  -->  

                    </div>
                    {{-- ============= --}}
                    <div class="row mt-2">
                        <div class="col-md-6"><label class="labels">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="{{date($user_data->dob)}}">
                            @error('dob')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                        <div class="col-md-6"><label class="labels">Gender</label>
                            <select name="gender" class="form-control"  >
                                <option selected disabled="">Choose Gender</option>
                                <option value="male" {{$user_data->gender == 'male' ? 'selected' :' '}}>Male</option>
                                <option value="female" {{$user_data->gender == 'female' ? 'selected' :' '}}>Female</option>
                                <option value="Other" {{$user_data->gender == 'other' ? 'selected' :' '}}>Other</option>
                                @error('gender')
                                <span class="text-danger"> {{$message}}</span>
                                @enderror
                            </select>
                        </div>
                    </div>
                    {{-- ========== --}}
                    <div class="row mt-2">
                        <div class="col-md-6"><label class="labels">Country</label>
                            <select name="country" class="form-control"  >
                                <option selected disabled="">Choose Country</option>
                                @foreach( $get_Country as $values)
                                <option value="{{  $values->name}}" selected="">{{  $values->name}}</option>
                                @endforeach
                              </select>
                              @error('country')
                              <span class="text-danger"> {{$message}}</span>
                              @enderror
                        </div>
                        <div class="col-md-6"><label class="labels">State</label>
                            <select name="state" class="form-control"  >
                                <option selected disabled="">Choose State</option>
                                @foreach( $get_state as $values)
                                <option value="{{  $values->name}}" selected=""  >{{  $values->name}}</option>
                                @endforeach
                              </select>
                              @error('state')
                              <span class="text-danger"> {{$message}}</span>
                              @enderror
                        </div>
                    </div>
                    {{-- ============= --}}               
                    <div class="row mt-2">
                        <div class="col-md-6"><label class="labels">City</label>
                            <input type="text" name="city" class="form-control"  value="{{$user_data->city}}">
                            @error('city')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                        <div class="col-md-6"><label class="labels">Mobile</label>
                            <input type="text" name="phone" class="form-control" value="{{$user_data->phone}}" >
                            @error('phone')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                    </div>

                    {{-- ============= --}}
                
                    <div class="row mt-2">
                        <div class="col-md-6"><label class="labels">Religion</label>
                            <select name="religion" class="form-control"  >
                          
                                
                                @foreach($get_religion as $value)
                                <option value="{{$value->name}}" {{ $value->id == $user_data->id ? 'selected' :''}} >{{$value->name}}</option>
                                @endforeach
                              
                                
                              </select>
                              @error('religion')
                              <span class="text-danger"> {{$message}}</span>
                              @enderror
                        </div>
                        <div class="col-md-6"><label class="labels">Community</label>
                            <select name="community" class="form-control"  >
                                <option selected disabled="">Choose community</option>
                                
                                <option value="Agrawal" label="Agrawal">Agrawal</option>

                                <option value="Brahmin" label="Brahmin">Brahmin</option>
                                <option value="Sikh" label="Sikh">Sikh</option>
                                <option value="Hindu" label="Hindu">Hindu</option>
                                <option value="Other" label="Other">Other</option>
                                <option value="jatt" >   Jatt </option>
                                <option value="Ad-Dharmi" >  Ad-Dharmi   </option>
                                <option value="Saini" >Saini</option>
                                <option value="Rajput" > Rajput  </option>
                                <option value="Ahluwalia" > Ahluwalia   </option>
                                <option value="Arora" >  Arora  </option>
                                <option value="Khatri" >  Khatri   </option>
                                <option value=" Ramgarhia" > Ramgarhia </option>
                                <option value="Other" label="Other">Other</option>
                              </select>
                              @error('community')
                              <span class="text-danger"> {{$message}}</span>
                              @enderror
                        </div>
                    </div>
                    {{-- height  --}}
                    <div class="row mt-2">
        
                        <!--=================-->
                    <div class="col-md-6"><label class="labels">Select Diet</label>
                            <select name="diet"  class="form-control" >

                                @foreach($get_diet as $values)
<option  value="{{$values->name}}" {{$values->id == $user_data->id ?'selected' : ''}}>{{$values->name}}</option>
                                @endforeach
                            </select>
                            @error('')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                        <!--//////////-->
                        
                        
                        <div class="col-md-6"><label class="labels">Select height</label>
                            <select name="height" id="height" class="form-control" >
                                <!--<option selected disabled="" >Select height</option>-->
                                @foreach($get_heights as $values)
<option  value="{{$values->name}}" {{$values->id == $user_data->id ?'selected' : ''}}>{{$values->name}}</option>
                                @endforeach
                            </select>
                            @error('height')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                    </div>
                    {{-- height  --}}
               {{-- ===================== --}}
               <div class="row mt-2">
                <div class="col-md-6"><label class="labels">Marital status</label>
                    <select name="marital_status" class="form-control"  >
                        <!--<option selected disabled=""> Marital status</option>-->
                        
                        @foreach($marital_status  as $value)
                        <option value="{{ $value->name}}" {{  $value->id ==  $user_data->id ?'selected' : '' }}>{{ $value->name}}</option>
                        @endforeach

                      </select>
                      @error('marital_status')
                      <span class="text-danger"> {{$message}}</span>
                      @enderror
                </div>
                {{-- ========== --}}
                <div class="col-md-6"><label class="labels">Profile created </label>
                    <select name="profile_created"   class="form-control" >
                        @foreach($profile_created as $value)
                        <option value="{{$value->name}}" label="{{$value->name}}" {{$user_data->id == $value->id }}>{{$value->name}}</option>
                        @endforeach
                    </select>
                    @error('profile_created')
                    <span class="text-danger"> {{$message}}</span>
                    @enderror
                </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                      {{-- ============== --}}
                      <div class="row mt-3">
                        <div class="col-md-12"><label class="labels">Address </label>
                            <textarea class="form-control" name="address" rows="3" placeholder="Enter your Address">{!!html_entity_decode($user_data->address)!!} </textarea>
                            @error('address')
                            <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                        <div class="col-md-12"><label class="labels"> Partner and Family
                        </label>
                            <textarea class="form-control" name="about_yourself" rows="3" placeholder="Describe yourself and patner here...">{{$user_data->about_yourself}}</textarea>
                            @error('about_yourself')
                            <span class="text-danger"> {{$message}}</span>
                            @enderror
                        </div>
                  <!--mother tongue-->
<div class="col-md-12"><label class="labels">Mother Tongue</label>    
<select name="mother_tongue"  class="form-control" >
<option disabled="" selected="selected">Select</option>
<optgroup id="mother_tongue-optgroup-Frequently Used" label="Frequently Used">Frequently Used</optgroup><option value="Hindi">Hindi</option>
<option value="Marathi">Marathi</option>
<option value="Punjabi" >Punjabi</option>
<option value="Bengali">Bengali</option>
<option value="Gujarati">Gujarati</option>
<option value="Urdu">Urdu</option>
<option value="Telugu">Telugu</option>
<option value="Kannada">Kannada</option>
<option value="English">English</option>
<option value="Tamil">Tamil</option>
<option value="Odia">Odia</option>
<option value="Marwari">Marwari</option>
<optgroup id="mother_tongue-optgroup-All Mother Tongues" label="All Mother Tongues">All Mother Tongues</optgroup>
<option value="Aka">Aka</option>
<option value="Arabic">Arabic</option>
<option value="Arunachali">Arunachali</option>
<option value="Assamese">Assamese</option>
<option value="Awadhi">Awadhi</option>
<option value="Baluchi">Baluchi</option>
<option value="Bengali">Bengali</option>
<option value="Bhojpuri">Bhojpuri</option>
<option value="Bhutia">Bhutia</option>
<option value="Brahui">Brahui</option>
<option value="Brij">Brij</option>
<option value="Burmese">Burmese</option>
<option value="Chattisgarhi">Chattisgarhi</option>
<option value="Chinese">Chinese</option>
<option value="Coorgi">Coorgi</option>
<option value="Dogri">Dogri</option>
<option value="English">English</option>
<option value="French">French</option>
<option value="Garhwali">Garhwali</option>
<option value="Garo">Garo</option>
<option value="Gujarati">Gujarati</option>
<option value="Haryanavi">Haryanavi</option>
<option value="Himachali/Pahari">Himachali/Pahari</option>
<option value="Hindi">Hindi</option>
<option value="Hindko">Hindko</option>
<option value="Kakbarak">Kakbarak</option>
<option value="Kanauji">Kanauji</option>
<option value="Kannada">Kannada</option>
<option value="Kashmiri">Kashmiri</option>
<option value="Khandesi">Khandesi</option>
<option value="Khasi">Khasi</option>
<option value="Konkani">Konkani</option>
<option value="Koshali">Koshali</option>
<option value="Kumaoni">Kumaoni</option>
<option value="Kutchi">Kutchi</option>
<option value="Ladakhi">Ladakhi</option>
<option value="Lepcha">Lepcha</option>
<option value="Magahi">Magahi</option>
<option value="Maithili">Maithili</option>
<option value="Malay">Malay</option>
<option value="Malayalam">Malayalam</option>
<option value="Manipuri">Manipuri</option>
<option value="Marathi">Marathi</option>
<option value="Marwari">Marwari</option>
<option value="Miji">Miji</option>
<option value="Mizo">Mizo</option>
<option value="Monpa">Monpa</option>
<option value="Nepali">Nepali</option>
<option value="Odia">Odia</option>
<option value="Pashto">Pashto</option>
<option value="Persian">Persian</option>
<option value="Punjabi">Punjabi</option>
<option value="Rajasthani">Rajasthani</option>
<option value="Russian">Russian</option>
<option value="Sanskrit">Sanskrit</option>
<option value="Santhali">Santhali</option>
<option value="Seraiki">Seraiki</option>
<option value="Sindhi">Sindhi</option>
<option value="Sinhala">Sinhala</option>
<option value="Sourashtra">Sourashtra</option>
<option value="Spanish">Spanish</option>
<option value="Swedish">Swedish</option>
<option value="Tagalog">Tagalog</option>
<option value="Tamil">Tamil</option>
<option value="Telugu">Telugu</option>
<option value="Tulu">Tulu</option>
<option value="Urdu">Urdu</option>
<option value="Other">Other</option>
</select>
   @error('mother_tongue')
    <span class="text-danger"> {{$message}}</span>
    @enderror
</div>
<!--mother tonue -->
                      
                     
    <!--Education -->
<div class="col-md-12">
    <label class="labels">Education </label>
        <select class="form-control" name="education">
        <option  selected="selected" disabled="disabled">-- select one --</option>
        <option value="No formal education">No formal education</option>
        <option value="Primary education">Primary education</option>
        <option value="Secondary education">Secondary education or high school</option>
        <option value="GED">GED</option>
        <option value="Vocational qualification">Vocational qualification</option>
        <option value="Bachelor's degree">Bachelor's degree</option>
        <option value="Master's degree">Master's degree</option>
        <option value="Doctorate or higher">Doctorate or higher</option>
        </select>
        @error('education')
        <span class="text-danger"> {{$message}}</span>
        @enderror
  </div>
 <!--education -->
<!--working as  -->
<div class="col-md-12"><label class="labels">Working with </label>
 <select name="Working_as"  class="form-control"  >
    <option selected="selected" disabled="disabled">Select Working with</option>
    <option value="Private Company" label="Private Company" >Private Company</option>
    <option value="Government / Public Sector" label="Government / Public Sector">Government / Public Sector</option>
    <option value="Defense / Civil Services" label="Defense / Civil Services">Defense / Civil Services</option>
    <option value="Business / Self Employed" label="Business / Self Employed">Business / Self Employed</option>
    <option value="Non Working" label="Not Working">Not Working</option>
</select>
        @error('Working_as')
        <span class="text-danger"> {{$message}}</span>
        @enderror
</div>
<!--working as -->
        <!--Work detail-->
            <div class="col-md-12"><label class="labels">Work detail </label>
            <textarea class="form-control" name="work_detail" rows="3" placeholder="Work detail..."></textarea>
                    @error('work_detail')
                    <span class="text-danger"> {{$message}}</span>
                    @enderror
            </div>
<!--Work detail-->
 
                     
                    </div>
                         {{-- ================ --}}
                    <div class="mt-5 text-center">
                        <button class="btn btn-primary profile-button" type="submit">Save Profile</button></div>

                        </form>
            </div>
        </div>
    </div>
    </div>
    </div>
</div>



  

<script>
 
        $(document).ready(function(){
        $('#multiImg').on('change', function(){ //on file input change
        if (window.File && window.FileReader && window.FileList && window.Blob) //check File API supported browser
      {
      var data = $(this)[0].files; //this file data    
       $.each(data, function(index, file){ //loop though each file
          if(/(\.|\/)(gif|jpe?g|png)$/i.test(file.type)){ //check supported file type
       var fRead = new FileReader(); //new filereader
       fRead.onload = (function(file){ //trigger function on successful read
       return function(e) {
       var img = $('<img/>').addClass('thumb').attr('src', e.target.result) .width(80)
                  .height(80); //create image element 
                      $('#preview_img').append(img); //append image to output element
                  };
                  })(file);
                  fRead.readAsDataURL(file); //URL representing the file's data.
              }
          });
           
      }else{
          alert("Your browser doesn't support File API!"); //if File API is absent
      }
   });
  });
   
</script>








@endsection     




