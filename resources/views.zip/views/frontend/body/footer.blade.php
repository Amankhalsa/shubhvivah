<div class="container-fluid">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 footer-section">
        <div class="main">
          <div class="col-xs-12 col-sm-12 col-md-12 footer-section1">
            <img src="{{asset('frontend/images/heart1.png')}}" alt="">
            <p>Copyright&copy; All Right Reserved 2021-2022</p>
            
          </div>
        </div>
      </div> 
    </div>
  </div>
  
  