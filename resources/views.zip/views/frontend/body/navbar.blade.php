<div class="row">



    <div class="col-xs-12 col-sm-12 col-md-12 head-section header start-style">
      <div class="col-xs-4 col-sm-4 col-md-2 head-logo1">
        <div class="col-xs-12 col-sm-12 col-md-12 head-logo2">
        <a href="https://shubhvivah.us/"> <img src="{{asset('frontend/images/logo2.png')}}" alt="Shubh Vivah" title="Shubh Vivah" class="logo-now"> 
        <img src="{{asset('frontend/images/head-logo.png')}}" alt="Shubh Vivah" title="Shubh Vivah" class="logo-change"></a>
      </div>
    </div>




    <div class="col-xs-8 col-sm-8 col-md-10 head-navigation1 ">
      <div class="col-xs-12 col-sm-12 col-md-12 head-navigation2">
          
          <div class="hg">+91-9781866164     </div>

          <div class="slide-container">
           
            <div class="js-nav">
              <div class="hamburger-box">
                <span>Menu</span>
                <div class="bun top"></div>
                <div class="meat"></div>
                <div class="bun bottom"></div>
              </div>
            </div>
            
              <nav class="menu">
              <p><img src="{{asset('frontend/images/heart.png')}}"><br> shubh vivah <br></p>
                <ul>
                  <li><a href="{{route('front.home.page')}}">home</a></li>
                  <li><a href="{{route('front.about.page')}}">about shubh vivah </a></li>
                  <li><a href="{{route('front.testimonials.page')}}"> shubh vivah reviews</a></li>
                  <li><a href="{{route('front.package.page')}}"> shubh vivah packages </a></li>
                  <li><a href="{{route('front.contact.page')}}">contact us </a></li>
                  <li><a href="{{route('login')}}">login </a></li>
                  <li><a href="{{route('register')}}">Register </a></li>


                  
                </ul>
              </nav>
            
          </div>
        





    </div>













</div>
</div>
</div>