<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright ©{{date('Y')}} shubhvivah. All rights reserved. Template by <a href="https://www.shubhvivah.us/">shubhvivah </a>.</p>
        </div>
    </div>
</div>